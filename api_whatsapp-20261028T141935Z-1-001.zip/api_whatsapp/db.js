const mysql = require('mysql2');

// Conexão simples com o MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'whatsapp_db'
});

db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar no banco MySQL:', err.message);
    } else {
        console.log('Conectado ao banco MySQL com sucesso!');
    }
});

module.exports = db;