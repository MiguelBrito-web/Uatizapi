const express = require('express');
const cors = require('cors');
const db = require('./db');

const app = express();
app.use(cors());
app.use(express.json());

// Rota de Login / Autenticação com MySQL
app.post('/api/auth/login', (req, res) => {
    const { phone, username, password } = req.body;

    if (!phone || !username || !password) {
        return res.status(400).json({ success: false, message: 'Todos os campos são obrigatórios!' });
    }

    // Busca o usuário no banco MySQL usando telefone e usuário
    const query = 'SELECT * FROM usuarios WHERE phone = ? AND username = ? AND password = ?';
    
    db.query(query, [phone, username, password], (err, results) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'Erro no banco de dados' });
        }

        if (results.length > 0) {
            return res.status(200).json({
                success: true,
                message: 'Login bem-sucedido!',
                user: results[0],
                token: 'mock-jwt-token-123'
            });
        } else {
            return res.status(401).json({ success: false, message: 'Telefone, usuário ou senha incorretos!' });
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});