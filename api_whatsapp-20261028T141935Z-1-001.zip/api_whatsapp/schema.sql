-- Script de criação do Banco de Dados para iniciantes

CREATE DATABASE IF NOT EXISTS whatsapp_db;
USE whatsapp_db;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    phone VARCHAR(20) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exemplo de inserção de usuário de teste
INSERT INTO usuarios (phone, username, password) 
VALUES ('11999999999', 'admin', '1234')
ON DUPLICATE KEY UPDATE username=username;