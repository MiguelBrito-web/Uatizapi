document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const phone = document.getElementById('phone').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch('http://localhost:3000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone, username, password })
        });

        const data = await response.json();
        if (response.ok) {
            alert('Login realizado com sucesso! Token: ' + data.token);
        } else {
            alert('Erro: ' + data.message);
        }
    } catch (err) {
        alert('Erro ao conectar com o servidor.');
    }
});